Rfactory compact source-resolution sticker pack, reference_only assets; background files full-resolution. Do not treat upscaled stickers as source-HD puzzle images.
